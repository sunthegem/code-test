require 'test_helper'

class MyfileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
