require 'test_helper'

class MydirectoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
